# Real-Time Support Chat System (Java)

A beginner-friendly console chat application using Java Socket Programming.

## Requirements
- JDK 8 or later
- Terminal / Command Prompt

## Files
- `src/ChatServer.java` — accepts clients and broadcasts messages
- `src/ChatClient.java` — connects to the server and sends/receives messages

## Run

Open a terminal in the project folder and compile:

```bash
javac -d out src/ChatServer.java src/ChatClient.java
```

Start the server in terminal 1:

```bash
java -cp out ChatServer
```

Start a client in terminal 2:

```bash
java -cp out ChatClient
```

Start another client in terminal 3 using the same command. Enter different usernames and chat.

By default, the client connects to `localhost` on port `5000`. For computers on the same network, change `SERVER_HOST` in `ChatClient.java` to the server computer's local IP address and allow port 5000 through the firewall.

## Notes
- This is an educational demo, not a production-ready support platform.
- Messages are not stored in a database and the connection is not encrypted.
- For a real deployment, add authentication, TLS, input validation, message persistence, and proper privacy controls.
