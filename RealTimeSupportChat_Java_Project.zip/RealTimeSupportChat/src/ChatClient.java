import java.io.*;
import java.net.*;
import java.util.Scanner;

public class ChatClient {
    private static final String SERVER_HOST = "localhost";
    private static final int SERVER_PORT = 5000;

    public static void main(String[] args) {
        try (
            Socket socket = new Socket(SERVER_HOST, SERVER_PORT);
            BufferedReader in = new BufferedReader(
                new InputStreamReader(socket.getInputStream()));
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            Scanner scanner = new Scanner(System.in)
        ) {
            System.out.println("Connected to support chat.");
            System.out.println(in.readLine()); // username prompt
            String username = scanner.nextLine().trim();
            if (username.isEmpty()) {
                username = "Guest";
            }
            out.println(username);

            Thread receiver = new Thread(() -> {
                try {
                    String serverMessage;
                    while ((serverMessage = in.readLine()) != null) {
                        System.out.println(serverMessage);
                    }
                } catch (IOException e) {
                    System.out.println("Disconnected from server.");
                }
            });
            receiver.setDaemon(true);
            receiver.start();

            System.out.println("Type messages below. Use /quit to exit.");
            while (scanner.hasNextLine()) {
                String message = scanner.nextLine();
                out.println(message);
                if (message.trim().equalsIgnoreCase("/quit")) {
                    break;
                }
            }
        } catch (ConnectException e) {
            System.out.println("Cannot connect. Start ChatServer first.");
        } catch (IOException e) {
            System.out.println("Client error: " + e.getMessage());
        }
    }
}
