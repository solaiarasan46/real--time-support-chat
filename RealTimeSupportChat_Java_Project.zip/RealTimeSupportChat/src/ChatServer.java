import java.io.*;
import java.net.*;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class ChatServer {
    private static final int PORT = 5000;
    private static final Set<ClientHandler> clients = ConcurrentHashMap.newKeySet();

    public static void main(String[] args) {
        System.out.println("Real-Time Support Chat Server");
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Server started on port " + PORT);
            while (true) {
                Socket socket = serverSocket.accept();
                ClientHandler client = new ClientHandler(socket);
                clients.add(client);
                client.start();
            }
        } catch (IOException e) {
            System.err.println("Server error: " + e.getMessage());
        }
    }

    private static void broadcast(String message, ClientHandler sender) {
        for (ClientHandler client : clients) {
            if (client != sender) {
                client.send(message);
            }
        }
        System.out.println(message);
    }

    private static class ClientHandler extends Thread {
        private final Socket socket;
        private PrintWriter out;
        private String username = "Guest";

        ClientHandler(Socket socket) {
            this.socket = socket;
        }

        void send(String message) {
            if (out != null) {
                out.println(message);
            }
        }

        @Override
        public void run() {
            try (
                BufferedReader in = new BufferedReader(
                    new InputStreamReader(socket.getInputStream()))
            ) {
                out = new PrintWriter(socket.getOutputStream(), true);
                out.println("Enter your username:");
                String suppliedName = in.readLine();
                if (suppliedName != null && !suppliedName.trim().isEmpty()) {
                    username = suppliedName.trim();
                }

                broadcast("[JOIN] " + username + " joined the chat.", this);
                out.println("Connected. Type /quit to leave.");

                String message;
                while ((message = in.readLine()) != null) {
                    if (message.trim().equalsIgnoreCase("/quit")) {
                        break;
                    }
                    if (!message.trim().isEmpty()) {
                        broadcast(username + ": " + message, this);
                        out.println("You: " + message);
                    }
                }
            } catch (IOException e) {
                System.out.println(username + " disconnected.");
            } finally {
                clients.remove(this);
                broadcast("[LEAVE] " + username + " left the chat.", this);
                try {
                    socket.close();
                } catch (IOException ignored) {
                }
            }
        }
    }
}
